/*
** EPITECH PROJECT, 2020
** B-CPE-110-PAR-1-3-bspushswap-perry.chouteau
** File description:
** test.c
*/

#include "../includes/bs_push_swap.h"

ps_t init_test(ps_t ps)
{
    ps.ac = 5;
    ps.l_a = malloc(sizeof(int) * ps.ac);
    ps.l_a[0] = 1;
    ps.l_a[1] = 2;
    ps.l_a[2] = 3;
    ps.l_a[3] = 4;
    ps.l_a[4] = 5;
    return ps;
}

ps_t init_test2(ps_t ps)
{
    ps.ac = 3;
    ps.l_a = malloc(sizeof(int) * ps.ac);
    ps.l_a[0] = 3;
    ps.l_a[1] = 2;
    ps.l_a[2] = 1;
    return ps;
}

ps_t init_test3(ps_t ps)
{
    ps.ac = 9;
    ps.l_a = malloc(sizeof(int) * ps.ac);
    ps.l_a[0] = 12;
    ps.l_a[1] = 45;
    ps.l_a[2] = 8;
    ps.l_a[3] = 32;
    ps.l_a[4] = 2000000;
    ps.l_a[5] = 6;
    ps.l_a[6] = 13;
    ps.l_a[7] = 25;
    ps.l_a[8] = 3;
    return ps;
}

ps_t init_test4(ps_t ps)
{
    ps.ac = 25;
    ps.l_a = malloc(sizeof(int) * ps.ac);
    for (int i = 0; i < ps.ac; i += 1)
        ps.l_a[i] = ps.ac - i;
    return ps;
}

Test (sa, index1_greater_than_index2)
{
    ps_t ps;

    ps.ac = 5;
    ps = init_test(ps);
    ps = sa(ps);
    cr_assert_eq(ps.l_a[0], 2);
    cr_assert_eq(ps.l_a[1], 1);
    cr_assert_eq(ps.l_a[2], 3);
    cr_assert_eq(ps.l_a[3], 4);
    cr_assert_eq(ps.l_a[4], 5);
}

Test (ra, index1_greater_than_index2)
{
    ps_t ps;

    ps = init_test(ps);
    ps = ra(ps);
    cr_assert_eq(ps.l_a[0], 2);
    cr_assert_eq(ps.l_a[1], 3);
    cr_assert_eq(ps.l_a[2], 4);
    cr_assert_eq(ps.l_a[3], 5);
    cr_assert_eq(ps.l_a[4], 1);
}

Test (swap_all, part1_4)
{
    ps_t ps;

    ps = init_test(ps);
    ps = swap_all(ps);
    cr_assert_eq(ps.l_a[0], 1);
    cr_assert_eq(ps.l_a[1], 2);
    cr_assert_eq(ps.l_a[2], 3);
    cr_assert_eq(ps.l_a[3], 4);
    cr_assert_eq(ps.l_a[4], 5);
}

Test (swap_all, part2_4)
{
    ps_t ps;

    ps = init_test2(ps);
    ps = swap_all(ps);
    cr_assert_eq(ps.l_a[0], 1);
    cr_assert_eq(ps.l_a[1], 2);
    cr_assert_eq(ps.l_a[2], 3);
}

Test (swap_all, part3_4)
{
    ps_t ps;

    ps = init_test3(ps);
    ps = swap_all(ps);
    cr_assert_eq(ps.l_a[0], 3);
    cr_assert_eq(ps.l_a[1], 6);
    cr_assert_eq(ps.l_a[2], 8);
    cr_assert_eq(ps.l_a[3], 12);
    cr_assert_eq(ps.l_a[4], 13);
    cr_assert_eq(ps.l_a[5], 25);
    cr_assert_eq(ps.l_a[6], 32);
    cr_assert_eq(ps.l_a[7], 45);
    cr_assert_eq(ps.l_a[8], 2000000);
}

Test (swap_all, part4_4)
{
    ps_t ps;

    ps = init_test4(ps);
    ps = swap_all(ps);
    cr_assert_eq(ps.l_a[0], 1);
    cr_assert_eq(ps.l_a[1], 2);
    cr_assert_eq(ps.l_a[2], 3);
    cr_assert_eq(ps.l_a[3], 4);
    cr_assert_eq(ps.l_a[4], 5);
    cr_assert_eq(ps.l_a[5], 6);
    cr_assert_eq(ps.l_a[6], 7);
    cr_assert_eq(ps.l_a[7], 8);
    cr_assert_eq(ps.l_a[8], 9);
    cr_assert_eq(ps.l_a[9], 10);
    cr_assert_eq(ps.l_a[10], 11);
    cr_assert_eq(ps.l_a[11], 12);
    cr_assert_eq(ps.l_a[12], 13);
    cr_assert_eq(ps.l_a[13], 14);
    cr_assert_eq(ps.l_a[14], 15);
    cr_assert_eq(ps.l_a[15], 16);
    cr_assert_eq(ps.l_a[16], 17);
    cr_assert_eq(ps.l_a[17], 18);
    cr_assert_eq(ps.l_a[18], 19);
    cr_assert_eq(ps.l_a[19], 20);
    cr_assert_eq(ps.l_a[20], 21);
    cr_assert_eq(ps.l_a[21], 22);
    cr_assert_eq(ps.l_a[22], 23);
    cr_assert_eq(ps.l_a[23], 24);
    cr_assert_eq(ps.l_a[24], 25);
}