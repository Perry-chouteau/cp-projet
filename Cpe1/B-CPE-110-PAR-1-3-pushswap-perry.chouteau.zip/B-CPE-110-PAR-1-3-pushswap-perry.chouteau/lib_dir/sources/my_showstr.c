/*
** EPITECH PROJECT, 2020
** my show str
** File description:
** my show str
*/

#include "../includes/my.h"

int my_showstr(char const *str)
{
    return 0;
}
