/*
** EPITECH PROJECT, 2020
** my compute square root
** File description:
** compute square root
*/

#include "../includes/my.h"

int my_compute_square_root(int nb)
{
    return 0;
}
