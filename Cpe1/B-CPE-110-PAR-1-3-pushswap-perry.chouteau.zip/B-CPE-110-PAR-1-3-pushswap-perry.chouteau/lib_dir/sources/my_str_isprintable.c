/*
** EPITECH PROJECT, 2020
** my str is printable
** File description:
** my str is printable returns True if all characters in the string \
** are printable or the string is empty. If not, it returns False.
*/

#include "../includes/my.h"

int my_str_isprintable(char const *str)
{
    return 0;
}
