/*
** EPITECH PROJECT, 2020
** my str is upper
** File description:
** say if a string is upper
*/

#include "../includes/my.h"

int my_str_isupper(char const *str)
{
    return 0;
}
