/*
** EPITECH PROJECT, 2020
** my_strncmp
** File description:
** Cette fonction permet de comparer deux chaînes de caractères
** et de savoir si la première est inférieure, égale ou supérieure à la seconde.
*/

#include "../includes/my.h"

int my_strncmp(char const *s1, char const *s2, int n)
{
    return 0;
}
