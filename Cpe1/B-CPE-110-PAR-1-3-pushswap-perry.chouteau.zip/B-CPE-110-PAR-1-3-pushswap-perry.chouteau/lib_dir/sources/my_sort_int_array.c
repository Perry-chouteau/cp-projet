/*
** EPITECH PROJECT, 2020
** my_sort_int_array
** File description:
** sort int array
*/

#include "../includes/my.h"

void my_sort_int_array(int *tab, int size)
{
    return ;
}
