/*
** EPITECH PROJECT, 2020
** my compute power rec
** File description:
** compute power rec
*/

#include "../includes/my.h"

int my_compute_power_rec(int nb, int power)
{
    return 0;
}
