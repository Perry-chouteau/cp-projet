/*
** EPITECH PROJECT, 2020
** my str cat
** File description:
** my str cat
*/

#include "../includes/my.h"

char *my_strcat(char *dest, char const *src)
{
    return 0;
}
