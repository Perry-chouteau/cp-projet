/*
** EPITECH PROJECT, 2020
** my show mem
** File description:
** my show mem
*/

#include "../includes/my.h"

int my_showmem(char const *str, int size)
{
    return 0;
}
