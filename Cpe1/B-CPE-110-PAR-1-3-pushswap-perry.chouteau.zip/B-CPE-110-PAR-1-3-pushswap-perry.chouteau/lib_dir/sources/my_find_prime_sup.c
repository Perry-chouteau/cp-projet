/*
** EPITECH PROJECT, 2020
** find prime sup
** File description:
** find prime sup
*/

#include "../includes/my.h"

int my_find_prime_sup(int nb)
{
    return 0;
}
