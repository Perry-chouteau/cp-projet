/*
** EPITECH PROJECT, 2020
** my str is lower
** File description:
** say if a string is lower
*/

#include "../includes/my.h"

int my_str_islower(char const *str)
{
    return 0;
}
