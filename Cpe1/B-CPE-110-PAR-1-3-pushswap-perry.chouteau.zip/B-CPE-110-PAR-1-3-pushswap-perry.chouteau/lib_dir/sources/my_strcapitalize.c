/*
** EPITECH PROJECT, 2020
** my str capitalize
** File description:
** It is the name of string of whose first character we want to capitalize.
*/

#include "../includes/my.h"

char *my_strcapitalize(char *str)
{
    return 0;
}
