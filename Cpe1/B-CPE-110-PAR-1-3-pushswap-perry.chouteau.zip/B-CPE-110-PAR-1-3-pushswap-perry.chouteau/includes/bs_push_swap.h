/*
** EPITECH PROJECT, 2020
** Psu2
** File description:
** navy.h
*/

#ifndef PUSWAP_H
#define PUSWAP_H

#include "../printf_dir/includes/my_printf.h"
#include "../lib_dir/includes/my.h"
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <criterion/criterion.h>

typedef struct
{
    int ac;
    int *l_a;
    int *l_b;
}ps_t;

ps_t init(int ac, char **av);
ps_t swap_all(ps_t ps);
ps_t sa(ps_t ps);
ps_t sb(ps_t ps);
ps_t sc(ps_t ps);
ps_t pa(ps_t ps);
ps_t pb(ps_t ps);
ps_t ra(ps_t ps);
ps_t rb(ps_t ps);
ps_t rr(ps_t ps);
ps_t rra(ps_t ps);
ps_t rrb(ps_t ps);
ps_t rrr(ps_t ps);

#endif