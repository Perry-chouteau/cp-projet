/*
** EPITECH PROJECT, 2020
** B-CPE-110-PAR-1-3-pushswap-perry.chouteau
** File description:
** swap_all.c
*/

#include "../includes/bs_push_swap.h"

ps_t swap_all(ps_t ps)
{
    int i;
    bool b = 1;

    while (b != 0) {
        b = 0;
        for (i = 0; i < (ps.ac - 1); i += 1) {
            if (ps.l_a[0] > ps.l_a[1]) {
                b = 1;
                ps = sa(ps);
            }
            ps = ra(ps);
            my_printf(" ");
        }
        ps = ra(ps);
        if (b != 0)
            my_printf(" ");
    }
    my_printf("\n");
    return ps;
}