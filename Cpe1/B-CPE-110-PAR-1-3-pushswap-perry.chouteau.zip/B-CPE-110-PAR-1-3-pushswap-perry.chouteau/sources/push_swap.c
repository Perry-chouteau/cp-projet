/*
** EPITECH PROJECT, 2020
** B-CPE-110-PAR-1-3-bspushswap-perry.chouteau
** File description:
** two_list.c
*/
#include "../includes/bs_push_swap.h"

void describe(void)
{
    my_printf("USAGE\n");

    my_printf("   ./push_swap [nombre1, nombre 2, ...]\n");
    my_printf("DESCRIPTION\n");
    my_printf("sort all number, giving, step by step, what we have done.\n");
    exit(0);
}

int error(ps_t ps)
{
    int i;
    for (i = 0; i < (ps.ac - 1); i += 1)
        if (ps.l_a[i] > ps.l_a[i + 1])
            return 0;
    my_printf("\n");
    exit(0);
}

int main(int ac, char **av)
{
    ps_t ps;

    if (ac == 1)
        exit(84);
    if (ac == 2 && av[1][0] == '-' && av[1][1] == 'h')
        describe();
    if (ac == 2 && (av[1][0] < '0' || av[1][0] > '9') && av[1][0] != '-')
        exit(84);
    if (ac == 2) {
        my_printf("\n");
        exit(0);
    }
    ps = init(ac, av);
    error(ps);
    ps = swap_all(ps);
    return 0;
}