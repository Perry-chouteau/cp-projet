/*
** EPITECH PROJECT, 2020
** B-CPE-110-PAR-1-3-pushswap-perry.chouteau
** File description:
** sp_ab.c
*/

#include "../includes/bs_push_swap.h"

ps_t sa(ps_t ps)
{
    int sv_nb = ps.l_a[0];

    ps.l_a[0] = ps.l_a[1];
    ps.l_a[1] = sv_nb;
    my_printf("sa ");
    return ps;
}

ps_t sb(ps_t ps)
{
    int sv_nb = ps.l_b[0];

    if (ps.ac < 2)
        return ps;
    ps.l_b[0] = ps.l_b[1];
    ps.l_b[1] = sv_nb;
    my_printf("sb\n");
    return ps;
}

ps_t sc(ps_t ps)
{
    ps = sa(ps);
    ps = sb(ps);
    my_printf("sc\n");
    return ps;
}

ps_t pa(ps_t ps)
{
    ps.l_a[0] = ps.l_b[0];
    my_printf("pa\n");
    return ps;
}

ps_t pb(ps_t ps)
{
    ps.l_b[0] = ps.l_a[0];
    my_printf("pb\n");
    return ps;
}