/*
** EPITECH PROJECT, 2020
** B-CPE-110-PAR-1-3-pushswap-perry.chouteau
** File description:
** rr_abr.c
*/

#include "../includes/bs_push_swap.h"

ps_t rra(ps_t ps)
{
    int i = ps.ac;
    int sv_nb = ps.l_a[i];

    for (; i > 1; i -= 1);
        ps.l_a[i] = ps.l_a[i - 1];
    ps.l_a[0] = sv_nb;
    my_printf("rra\n");
    return ps;
}

ps_t rrb(ps_t ps)
{
        int i = ps.ac;
    int sv_nb = ps.l_b[i];

    for (; i > 0; i -= 1)
        ps.l_b[i] = ps.l_b[i + 1];
    ps.l_b[0] = sv_nb;
    my_printf("rrb\n");
    return ps;
}

ps_t rrr(ps_t ps)
{
    ps = rra(ps);
    ps = rrb(ps);
    my_printf("rrr\n");
    return ps;
}