/*
** EPITECH PROJECT, 2020
** B-CPE-110-PAR-1-3-pushswap-perry.chouteau
** File description:
** init.c
*/

#include "../includes/bs_push_swap.h"

ps_t init(int ac, char **av)
{
    ps_t ps;

    ps.ac = ac - 1;
    ps.l_a = malloc(sizeof(int) * ac - 1);
    ps.l_b = malloc(sizeof(int) * ac - 1);
    for (int i = 0; i < ac; i += 1)
        ps.l_a[i - 1] = my_getnbr(av[i]);
    return ps;
}