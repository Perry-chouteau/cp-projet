/*
** EPITECH PROJECT, 2020
** B-CPE-110-PAR-1-3-pushswap-perry.chouteau
** File description:
** r_abr.c
*/

#include "../includes/bs_push_swap.h"

//ra check//

ps_t ra(ps_t ps)
{
    int i = 0;
    int sv_nb = ps.l_a[i];

    for (; i < (ps.ac - 1); i += 1)
        ps.l_a [i] = ps.l_a [i + 1];
    ps.l_a [i] = sv_nb;
    my_printf("ra");
    return ps;
}

ps_t rb(ps_t ps)
{
    int i = 0;
    int sv_nb = ps.l_b[i];

    for (; i < (ps.ac - 1); i += 1)
        ps.l_b [i] = ps.l_b [i + 1];
    ps.l_b [i] = sv_nb;
    my_printf("ra ");
    return ps;
}

ps_t rr(ps_t ps)
{
    ps = ra(ps);
    ps = rb(ps);
    my_printf("rr\n");
    return ps;
}